#!/bin/bash

sh insert.sh &
sh update.sh &
sh delete.sh &
