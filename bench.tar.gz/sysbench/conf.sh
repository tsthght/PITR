
host=10.9.141.212
port=4000
user=root
password=''
tcount=1
tsize=1000
threads=1
dbname=sbtest2

# report interval
interval=10

# max time in seconds
maxtime=60000

# just large enough to fit maxtime
requests=2000000000000

driver=mysql
