
host=10.9.1.135
port=4000
user=root
password=''
tcount=1
tsize=20000000
thread=15
dbname=sbtest2

# report interval
interval=10

# max time in seconds# 
maxtime=60000

# just large enough to fit maxtime
requests=150000

driver=mysql
