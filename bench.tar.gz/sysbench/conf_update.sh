
host=10.9.1.135
port=4000
user=root
password=''
tcount=1
tsize=10000
threads=256
dbname=sbtest2

# report interval
interval=10

# max time in seconds
maxtime=60000

# just large enough to fit maxtime
requests=200000

driver=mysql
