#!/bin/bash

set -x

. ./conf_insert.sh

sysbench --test=./lua-tests/db/insert.lua --db-driver=${driver} --mysql-host=${host} --mysql-port=${port} \
 --mysql-user=${user} --mysql-password=${password} --mysql-db=${dbname} \
 --oltp-tables-count=${tcount} --oltp-table-size=${tsize} --rand-type=uniform \
 --num-threads=${thread} --report-interval=${interval} \
 --events=${requests} --percentile=95 --max-time=${maxtime} run
