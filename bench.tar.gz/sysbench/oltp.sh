#!/bin/bash

set -x

. ./conf.sh
# 
#    oltp_point_selects = tonumber(oltp_point_selects or 10)
#    oltp_simple_ranges = tonumber(oltp_simple_ranges or 1)
#    oltp_sum_ranges = tonumber(oltp_sum_ranges or 1)
#    oltp_order_ranges = tonumber(oltp_order_ranges or 1)
#    oltp_distinct_ranges = tonumber(oltp_distinct_ranges or 1)
#    oltp_index_updates = tonumber(oltp_index_updates or 1)
#    oltp_non_index_updates = tonumber(oltp_non_index_updates or 1)

# run
sysbench --test=./lua-tests/db/oltp.lua --db-driver=${driver} --mysql-host=${host} --mysql-port=${port} \
  --mysql-user=${user} --mysql-password=${password} --mysql-db=${dbname} \
  --oltp-tables-count=${tcount} --oltp-table-size=${tsize} \
  --num-threads=${threads} --max-requests=${requests} \
  --oltp-read-only=off --report-interval=${interval} --rand-type=uniform \
  --oltp_point_selects
  --max-time=${maxtime} --percentile=95 run
